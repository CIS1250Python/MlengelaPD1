# ----------------------------------------------------------------------------
# Program: MlengelaDP1
# Programmer: Daudi Mlengela (dnlengela@cnm.edu)(mlengelad@gmail.com)
# Instructor: Thomas Gitierrez (tgutierrez@cnm.edu)
# Date: September 2nd, 2022
# Purpose: provides user capability to calculate volume of a pyramid.
# ----------------------------------------------------------------------------

from math import sqrt

class PyramidCalcs:

   def __init__(self, height = 0, length = 0):
      self.height = height
      self.length = length
      
h = float (input("Please enter the pyramid height in feet: "))
a = float (input("Please enter the lenght of the pyramid base:  "))

print(f"You entered: {h} (height) and: {a} (base length)")
      
# ----------------------------------------------------------------------------
# The volume is: a**2 * h / 3 (where a is the length of the base, h the height)
# ----------------------------------------------------------------------------

volume = a * a * h / 3

print(f"Volume: {volume:.3f}")

# ----------------------------------------------------------------------------
# Calculate the slant height, which is: sqrt(h^2 + (a/2)**2)
# ----------------------------------------------------------------------------

s = sqrt(h * h + (a / 2) * (a / 2))

# ----------------------------------------------------------------------------
# Determine the area of one side and then the total surface area
# ----------------------------------------------------------------------------

areaOneSide = s * a / 2
totalArea   = 4 * areaOneSide

print(f"Surface Area: {totalArea:.3f}")


